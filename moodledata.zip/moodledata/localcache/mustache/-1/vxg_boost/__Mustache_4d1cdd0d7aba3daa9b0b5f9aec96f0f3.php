<?php

class __Mustache_4d1cdd0d7aba3daa9b0b5f9aec96f0f3 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<li class="list-group-item pl-0 pr-0">
';
        $buffer .= $indent . '    <div class="row">
';
        $buffer .= $indent . '        <div class="col-8 pr-0">
';
        $buffer .= $indent . '            <div class="d-flex flex-row align-items-center" style="height: 32px">
';
        $buffer .= $indent . '                <div class="bg-pulse-grey rounded-circle" style="height: 32px; width: 32px;"></div>
';
        $buffer .= $indent . '                <div style="flex: 1" class="pl-2">
';
        $buffer .= $indent . '                    <div class="bg-pulse-grey w-100" style="height: 15px;"></div>
';
        $buffer .= $indent . '                    <div class="bg-pulse-grey w-75 mt-1" style="height: 10px;"></div>
';
        $buffer .= $indent . '                </div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="col-4 pr-3">
';
        $buffer .= $indent . '            <div class="d-flex flex-row justify-content-end" style="height: 32px; padding-top: 2px">
';
        $buffer .= $indent . '                <div class="bg-pulse-grey w-75" style="height: 15px;"></div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</li>
';

        return $buffer;
    }
}
