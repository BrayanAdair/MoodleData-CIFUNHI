<?php

class __Mustache_2d429305d1f5438a420b8adb8f622ea6 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>
';

        return $buffer;
    }
}
