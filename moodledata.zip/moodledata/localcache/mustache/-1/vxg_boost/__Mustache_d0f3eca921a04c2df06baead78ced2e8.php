<?php

class __Mustache_d0f3eca921a04c2df06baead78ced2e8 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="d-flex">
';
        $buffer .= $indent . '    <div class="bg-pulse-grey w-100" style="height: 80px"></div>
';
        $buffer .= $indent . '    <div class="mx-2 mb-2 align-self-end bg-pulse-grey" style="height: 20px; width: 20px"></div>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}
