<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'format_calendar', language 'es_mx', version '3.11'.
 *
 * @package     format_calendar
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['currentday'] = 'Día actual';
$string['dailyoutline'] = 'Resumen diario';
$string['day'] = 'Día';
$string['dayfriday'] = 'Viernes';
$string['dayhide'] = 'Ocultar este día desde {$a}';
$string['daymonday'] = 'Lunes';
$string['daysaturday'] = 'Sábado';
$string['dayshow'] = 'Mostrar este día a {$a}';
$string['daysunday'] = 'Domingo';
$string['daythursday'] = 'Jueves';
$string['daytuesday'] = 'Martes';
$string['daywednesday'] = 'Miércoles';
$string['displayAllMonths'] = 'Año';
$string['displayCurrentMonth'] = 'Mes';
$string['displayCurrentWeek'] = 'Semana';
$string['hidedayfromothers'] = 'Ocultar día';
$string['hidefromothers'] = 'Ocultar día';
$string['page-course-view-calendar'] = 'Cualquier página principal de curso en formato de calendario';
$string['page-course-view-calendar-x'] = 'Cualquier página de curso en formato de calendario';
$string['pluginname'] = 'Formato de calendario';
$string['section0name'] = 'General';
$string['sectionname'] = 'Día';
$string['showalldays'] = 'Mostrar todos los días';
$string['showdayfromothers'] = 'Mostar día';
$string['showfromothers'] = 'Mostar día';
$string['showonlyday'] = 'Mostrar solamente el día {$a}';
$string['toggleWeekends'] = 'Ocultar/Mostrar Fines de Semana';
